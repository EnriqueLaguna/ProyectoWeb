# MinecraftTradewarehouseWebPage.ItemApi

All URIs are relative to *https://virtserver.swaggerhub.com/EnriqueLaguna/Proyecto_Web/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**addItem**](ItemApi.md#addItem) | **POST** /api/items/ | Add a new item to the warehouse
[**deleteItem**](ItemApi.md#deleteItem) | **DELETE** /api/items/ | Delete item from the database
[**getItem**](ItemApi.md#getItem) | **GET** /api/items/ | Get one or multiple items to review
[**updateItem**](ItemApi.md#updateItem) | **PUT** /api/items/ | Updates the selected item


<a name="addItem"></a>
# **addItem**
> addItem(item)

Add a new item to the warehouse

### Example
```javascript
var MinecraftTradewarehouseWebPage = require('minecraft_tradewarehouse_web_page');

var apiInstance = new MinecraftTradewarehouseWebPage.ItemApi();

var item = new MinecraftTradewarehouseWebPage.Item(); // Item | Item that will be added to the Data Base


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
};
apiInstance.addItem(item, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **item** | [**Item**](Item.md)| Item that will be added to the Data Base | 

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml

<a name="deleteItem"></a>
# **deleteItem**
> deleteItem(item)

Delete item from the database

### Example
```javascript
var MinecraftTradewarehouseWebPage = require('minecraft_tradewarehouse_web_page');

var apiInstance = new MinecraftTradewarehouseWebPage.ItemApi();

var item = new MinecraftTradewarehouseWebPage.Item(); // Item | Item will be eliminated from the database


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
};
apiInstance.deleteItem(item, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **item** | [**Item**](Item.md)| Item will be eliminated from the database | 

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml

<a name="getItem"></a>
# **getItem**
> getItem(opts)

Get one or multiple items to review

### Example
```javascript
var MinecraftTradewarehouseWebPage = require('minecraft_tradewarehouse_web_page');

var apiInstance = new MinecraftTradewarehouseWebPage.ItemApi();

var opts = { 
  'item': new MinecraftTradewarehouseWebPage.Item() // Item | Item(s) that will be displayed in the page
};

var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
};
apiInstance.getItem(opts, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **item** | [**Item**](Item.md)| Item(s) that will be displayed in the page | [optional] 

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml

<a name="updateItem"></a>
# **updateItem**
> Item updateItem(opts)

Updates the selected item

### Example
```javascript
var MinecraftTradewarehouseWebPage = require('minecraft_tradewarehouse_web_page');

var apiInstance = new MinecraftTradewarehouseWebPage.ItemApi();

var opts = { 
  'item': new MinecraftTradewarehouseWebPage.Item() // Item | Item that will be updated with new data
};

var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.updateItem(opts, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **item** | [**Item**](Item.md)| Item that will be updated with new data | [optional] 

### Return type

[**Item**](Item.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml

