# MinecraftTradewarehouseWebPage.UserApi

All URIs are relative to *https://virtserver.swaggerhub.com/EnriqueLaguna/Proyecto_Web/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**createUser**](UserApi.md#createUser) | **POST** /api/users/ | Create user
[**deleteUser**](UserApi.md#deleteUser) | **DELETE** /api/users/:email | Deletes an user from the Data base
[**foundUserInTheDataBase**](UserApi.md#foundUserInTheDataBase) | **GET** /api/users/ | Verifies if the user is in the system, uses JWT
[**loginUser**](UserApi.md#loginUser) | **POST** /api/login | Logs user into the system
[**updateUser**](UserApi.md#updateUser) | **PUT** /api/users/:email | Updates the data of the login user


<a name="createUser"></a>
# **createUser**
> User createUser(body)

Create user

This action can be done for anyone who want to Login in the page

### Example
```javascript
var MinecraftTradewarehouseWebPage = require('minecraft_tradewarehouse_web_page');

var apiInstance = new MinecraftTradewarehouseWebPage.UserApi();

var body = new MinecraftTradewarehouseWebPage.User(); // User | Created user object


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.createUser(body, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**User**](User.md)| Created user object | 

### Return type

[**User**](User.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

<a name="deleteUser"></a>
# **deleteUser**
> User deleteUser(email)

Deletes an user from the Data base

### Example
```javascript
var MinecraftTradewarehouseWebPage = require('minecraft_tradewarehouse_web_page');

var apiInstance = new MinecraftTradewarehouseWebPage.UserApi();

var email = "email_example"; // String | The email is used to find the user


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.deleteUser(email, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **email** | **String**| The email is used to find the user | 

### Return type

[**User**](User.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

<a name="foundUserInTheDataBase"></a>
# **foundUserInTheDataBase**
> foundUserInTheDataBase(token)

Verifies if the user is in the system, uses JWT

### Example
```javascript
var MinecraftTradewarehouseWebPage = require('minecraft_tradewarehouse_web_page');

var apiInstance = new MinecraftTradewarehouseWebPage.UserApi();

var token = "token_example"; // String | The token needed for the authentication


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
};
apiInstance.foundUserInTheDataBase(token, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **token** | **String**| The token needed for the authentication | 

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, applicacion/xml

<a name="loginUser"></a>
# **loginUser**
> loginUser(email, password)

Logs user into the system

### Example
```javascript
var MinecraftTradewarehouseWebPage = require('minecraft_tradewarehouse_web_page');

var apiInstance = new MinecraftTradewarehouseWebPage.UserApi();

var email = "email_example"; // String | The user email for login

var password = "password_example"; // String | The password for login in clear text


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
};
apiInstance.loginUser(email, password, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **email** | **String**| The user email for login | 
 **password** | **String**| The password for login in clear text | 

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

<a name="updateUser"></a>
# **updateUser**
> updateUser(body)

Updates the data of the login user

### Example
```javascript
var MinecraftTradewarehouseWebPage = require('minecraft_tradewarehouse_web_page');

var apiInstance = new MinecraftTradewarehouseWebPage.UserApi();

var body = new MinecraftTradewarehouseWebPage.User(); // User | Data that the user can modify


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
};
apiInstance.updateUser(body, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**User**](User.md)| Data that the user can modify | 

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml

