# MinecraftTradewarehouseWebPage.Trade

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**nombreUsuario** | **String** |  | 
**nombreItem** | **String** |  | 
**precio** | **Number** |  | 
**fecha** | **String** |  | 


