# MinecraftTradewarehouseWebPage.Item

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**itemName** | **String** |  | 
**itemImage** | **String** |  | 
**receta** | **String** |  | 
**durabilidad** | **Number** |  | 
**descripcion** | **String** |  | 


