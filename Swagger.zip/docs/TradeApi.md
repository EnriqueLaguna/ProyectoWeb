# MinecraftTradewarehouseWebPage.TradeApi

All URIs are relative to *https://virtserver.swaggerhub.com/EnriqueLaguna/Proyecto_Web/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**createTrade**](TradeApi.md#createTrade) | **POST** /api/trades/ | Create a trade using items from the database
[**deleteTrade**](TradeApi.md#deleteTrade) | **DELETE** /api/trades/ | Delete an existing trade from the database
[**getTrades**](TradeApi.md#getTrades) | **GET** /api/trades/ | Get a trade or a list of trades
[**updateTrade**](TradeApi.md#updateTrade) | **PUT** /api/trades/ | Update an existing trade in the database


<a name="createTrade"></a>
# **createTrade**
> createTrade(trade)

Create a trade using items from the database

### Example
```javascript
var MinecraftTradewarehouseWebPage = require('minecraft_tradewarehouse_web_page');

var apiInstance = new MinecraftTradewarehouseWebPage.TradeApi();

var trade = new MinecraftTradewarehouseWebPage.Trade(); // Trade | The trade will be created with this information


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
};
apiInstance.createTrade(trade, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **trade** | [**Trade**](Trade.md)| The trade will be created with this information | 

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml

<a name="deleteTrade"></a>
# **deleteTrade**
> Trade deleteTrade(opts)

Delete an existing trade from the database

### Example
```javascript
var MinecraftTradewarehouseWebPage = require('minecraft_tradewarehouse_web_page');

var apiInstance = new MinecraftTradewarehouseWebPage.TradeApi();

var opts = { 
  'trade': new MinecraftTradewarehouseWebPage.Trade() // Trade | Delete the selected trade
};

var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.deleteTrade(opts, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **trade** | [**Trade**](Trade.md)| Delete the selected trade | [optional] 

### Return type

[**Trade**](Trade.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: applicaton/json, application/xml

<a name="getTrades"></a>
# **getTrades**
> getTrades(opts)

Get a trade or a list of trades

### Example
```javascript
var MinecraftTradewarehouseWebPage = require('minecraft_tradewarehouse_web_page');

var apiInstance = new MinecraftTradewarehouseWebPage.TradeApi();

var opts = { 
  'trade': new MinecraftTradewarehouseWebPage.Trade() // Trade | Trades showed to the user
};

var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
};
apiInstance.getTrades(opts, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **trade** | [**Trade**](Trade.md)| Trades showed to the user | [optional] 

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

<a name="updateTrade"></a>
# **updateTrade**
> updateTrade(opts)

Update an existing trade in the database

### Example
```javascript
var MinecraftTradewarehouseWebPage = require('minecraft_tradewarehouse_web_page');

var apiInstance = new MinecraftTradewarehouseWebPage.TradeApi();

var opts = { 
  'trade': new MinecraftTradewarehouseWebPage.Trade() // Trade | Update the data on the selected trade
};

var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
};
apiInstance.updateTrade(opts, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **trade** | [**Trade**](Trade.md)| Update the data on the selected trade | [optional] 

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml

