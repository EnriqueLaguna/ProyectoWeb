# MinecraftTradewarehouseWebPage.User

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** |  | 
**lastName** | **String** |  | 
**email** | **String** |  | 
**password** | **String** |  | 
**birthDay** | **String** |  | 
**sexo** | **String** |  | 
**image** | **String** |  | [optional] 


